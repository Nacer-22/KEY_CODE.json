package com.injector.secured;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.android.material.tabs.TabLayout;
import rikka.shizuku.Shizuku;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private LinearLayout layoutMainTab, layoutPermissionsTab;
    private EditText etLicenseKey;
    private Button btnActivate, btnInjectAndLaunch;
    private TextView tvShizukuStatus;
    private boolean isActivated = false;
    private Button btnGrantShizuku, btnGrantStorage;

    private final String TARGET_PATH = "/storage/emulated/0/Android/data/com.dts.freefireth/files/";
    private final String TARGET_PACKAGE = "com.dts.freefireth";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = findViewById(R.id.tabLayout);
        layoutMainTab = findViewById(R.id.layoutMainTab);
        layoutPermissionsTab = findViewById(R.id.layoutPermissionsTab);

        etLicenseKey = findViewById(R.id.etLicenseKey);
        btnActivate = findViewById(R.id.btnActivate);
        btnInjectAndLaunch = findViewById(R.id.btnInjectAndLaunch);
        tvShizukuStatus = findViewById(R.id.tvShizukuStatus);

        btnGrantShizuku = findViewById(R.id.btnGrantShizuku);
        btnGrantStorage = findViewById(R.id.btnGrantStorage);

        setupTabs();
        checkShizukuPermission();

        btnActivate.setOnClickListener(v -> {
            String key = etLicenseKey.getText().toString().trim();
            if (!key.isEmpty()) {
                isActivated = true;
                Toast.makeText(MainActivity.this, "تم تفعيل المفتاح بنجاح!", Toast.LENGTH_SHORT).show();
                btnInjectAndLaunch.setEnabled(true);
            } else {
                Toast.makeText(MainActivity.this, "يرجى إدخال كود التفعيل أولاً", Toast.LENGTH_SHORT).show();
            }
        });

        btnInjectAndLaunch.setOnClickListener(v -> performInjectionAndLaunch());
        btnGrantShizuku.setOnClickListener(v -> requestShizukuPermission());
        btnGrantStorage.setOnClickListener(v -> requestStoragePermission());
    }

    private void setupTabs() {
        tabLayout.addTab(tabLayout.newTab().setText("الصفحة الرئيسية"));
        tabLayout.addTab(tabLayout.newTab().setText("إعطاء الصلاحيات"));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    layoutMainTab.setVisibility(View.VISIBLE);
                    layoutPermissionsTab.setVisibility(View.GONE);
                } else {
                    layoutMainTab.setVisibility(View.GONE);
                    layoutPermissionsTab.setVisibility(View.VISIBLE);
                }
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void checkShizukuPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    tvShizukuStatus.setText("متصل وممنوح الصلاحية");
                    tvShizukuStatus.setTextColor(0xFF10B981);
                } else {
                    tvShizukuStatus.setText("متصل (بانتظار الصلاحية)");
                    tvShizukuStatus.setTextColor(0xFFF59E0B);
                }
            } else {
                tvShizukuStatus.setText("غير متصل");
                tvShizukuStatus.setTextColor(0xFFEF4444);
            }
        } catch (Exception e) {
            tvShizukuStatus.setText("غير متصل");
            tvShizukuStatus.setTextColor(0xFFEF4444);
        }
    }

    private void requestShizukuPermission() {
        try {
            if (Shizuku.pingBinder()) {
                Shizuku.requestPermission(0);
                Toast.makeText(this, "تم طلب صلاحية Shizuku", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "تأكد من تشغيل تطبيق Shizuku أولاً!", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "خطأ في Shizuku: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                }
            } else {
                Toast.makeText(this, "صلاحية الملفات ممنوحة بالفعل!", Toast.LENGTH_SHORT).show();
            }
        } else {
            ActivityCompat.requestPermissions(this, new String[]{
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            }, 100);
        }
    }

    private void performInjectionAndLaunch() {
        if (!isActivated) return;

        try {
            File f1 = extractAsset("file1.dat");
            File f2 = extractAsset("file2.dat");

            String command = "mkdir -p " + TARGET_PATH + " && cp -f " + f1.getAbsolutePath() + " " + TARGET_PATH + "/file1.dat && cp -f " + f2.getAbsolutePath() + " " + TARGET_PATH + "/file2.dat";
            Process process = Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                Toast.makeText(this, "تمت عملية الحقن بنجاح! جاري فتح اللعبة...", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "محاولة فتح اللعبة مباشرة...", Toast.LENGTH_SHORT).show();
            }
            launchFreeFire();
        } catch (Exception e) {
            Toast.makeText(this, "خطأ في الحقن: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            launchFreeFire();
        }
    }

    private void launchFreeFire() {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(TARGET_PACKAGE);
        if (launchIntent != null) {
            startActivity(launchIntent);
        } else {
            Toast.makeText(this, "التطبيق com.dts.freefireth غير مثبت!", Toast.LENGTH_LONG).show();
        }
    }

    private File extractAsset(String filename) throws Exception {
        File cacheFile = new File(getCacheDir(), filename);
        InputStream is = getAssets().open("files/" + filename);
        FileOutputStream fos = new FileOutputStream(cacheFile);
        byte[] buffer = new byte[1024];
        int read;
        while ((read = is.read(buffer)) != -1) {
            fos.write(buffer, 0, read);
        }
        is.close();
        fos.flush();
        fos.close();
        return cacheFile;
    }
}
