# AI Project Specification & Context Manifest
- **App Name:** Red & Black Secured Injector (`com.injector.secured`)
- **Target App to Launch:** Free Fire (TH) `com.dts.freefireth`
- **Target Injection Path:** `/storage/emulated/0/Android/data/com.dts.freefireth/files/`
- **Design System:** Dark Theme with Red (#DC2626) and Black (#0A0A0A) accents.
- **Features:**
  1. Tab 1 (Home): License Key activation input, Shizuku connection status indicator, and an action button labeled "اضغط هنا للحقن" which performs the file injection via Shizuku and immediately launches Free Fire (`com.dts.freefireth`).
  2. Tab 2 (Permissions): Buttons to grant Shizuku permission and full Storage/Files access.
  3. Security: Native C++ anti-debug and root/emulator checks.
